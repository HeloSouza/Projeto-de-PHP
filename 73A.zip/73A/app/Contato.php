<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Contato extends Model
{
    //
    public function lista()
    {
        return (object)
        [
            (object) ["nome"=>"joao","cel"=>"1498789989"],
            (object) ["nome"=>"gabriel","cel"=>"1498789875"]
        ];
    }

}
