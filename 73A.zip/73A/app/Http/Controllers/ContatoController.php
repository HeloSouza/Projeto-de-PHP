<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ContatoController extends Controller
{
    public function index($nota)
    {
        return "Aluno nota $nota!";
    }

    public function formulario() //parametro para receber informacoes post
    {
        $nome = $_POST['nome'];
        $senha = $_POST['senha'];
        //dd($req);
        return view("Contatos.index", compact('nome', 'senha')); //passagem da variavel
        //return "Aluno nota $nota!";
    }
}
