<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ContatoController extends Controller
{
    public function index($nota)
    {
        return "Aluno nota $nota!";
    }

    public function formulario() //parametro para receber informacoes post
    {
        $contatos = [

            ['nome'=>'Helo', 'cel'=>'14991021600'],
            ['nome'=>'Helo', 'cel'=>'14991021600']

        ];
        return view("Contatos.index", compact("contatos"));
    }
}
