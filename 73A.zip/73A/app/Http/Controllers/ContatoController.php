<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Contato;

class ContatoController extends Controller
{
    public function index($nota)
    {
        return "Aluno nota $nota!";
    }

    public function formulario() //parametro para receber informacoes post
    {
        //$contatos = [

          //  ['nome'=>'Helo', 'cel'=>'14991021600'],
         //   ['nome'=>'Helo', 'cel'=>'14991021600']

       // ];
        $contatos = new Contato; //modelo contato //objeto no plural e a classe no singular
        //dd($contatos->lista());
        $listaContatos = $contatos->lista(); //na lista há os dados contidos na classe Contato.php
        return view("Contatos.index", compact("listaContatos"));
    }
}
