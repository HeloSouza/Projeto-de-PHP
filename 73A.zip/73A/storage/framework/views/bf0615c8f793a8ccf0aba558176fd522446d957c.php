<?php echo $__env->make("layout._cabecalho", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->yieldContent("conteudo"); ?>

<?php echo $__env->make("layout._rodape", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
