<h3>Estou dentro da visão</h3>

<table>
    <tr>
        <td>Nome</td>
        <td>Cel</td>
    </tr>
    <?php $__currentLoopData = $contatos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contato): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <tr>
            <td><?php echo e($contato['nome']); ?></td>
            <td><?php echo e($contato['cel']); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</table>

