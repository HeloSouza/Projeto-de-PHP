<h3>Estou dentro da visão</h3>
<table>
<tr>
<td><?php echo e($nome); ?></td>
<td><?php echo e($senha); ?></td>
</tr>

