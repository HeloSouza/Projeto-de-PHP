<?php $__env->startSection("titulo", "Contatos"); ?>

<?php $__env->startSection("conteudo"); ?>

<table border = "1">

    <tr>
        <td>Nome</td>
        <td>Cel</td>
    </tr>

    <?php $__currentLoopData = $listaContatos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $listaContato): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

        <tr>
            <td><?php echo e($listaContato->nome); ?></td>
            <td><?php echo e($listaContato->cel); ?></td>
        </tr>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

</table>

<?php $__env->stopSection(); ?>


<?php echo $__env->make("layout.site", array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>