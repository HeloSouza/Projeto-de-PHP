<h3>Estou dentro da visão</h3>

<table>
    <tr>
        <td>Nome</td>
        <td>Cel</td>
    </tr>
    @foreach($contatos as $contato)
        <tr>
            <td>{{ $contato['nome'] }}</td>
            <td>{{ $contato['cel'] }}</td>
        </tr>
    @endforeach
</table>

