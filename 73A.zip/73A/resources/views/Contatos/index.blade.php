<h3>Estou dentro da visão</h3>
<table>
<tr>
<td>{{ $nome }}</td>
<td>{{ $senha }}</td>
</tr>

