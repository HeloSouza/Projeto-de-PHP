@extends("layout.site")

@section("titulo", "Contatos")

@section("conteudo")

<table border = "1">

    <tr>
        <td>Nome</td>
        <td>Cel</td>
    </tr>

    @foreach($listaContatos as $listaContato)

        <tr>
            <td>{{ $listaContato->nome }}</td>
            <td>{{ $listaContato->cel }}</td>
        </tr>

    @endforeach

</table>

@endsection

