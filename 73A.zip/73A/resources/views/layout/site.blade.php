@include("layout._cabecalho")

@yield("conteudo")

@include("layout._rodape")
